import itertools
import random
import binascii
import struct
import logging
import codecs
import hashlib
class Cores:
    '''lib cores
    ex:
        brainiac_utils.cores.$cor

            cyanClaro = "\033[1;36m"
            vermelho = '\033[31;1m'
            verde = '\033[32;1m'
            azul = '\033[34;1m'
            normal = '\033[0;0m'
            amarelo = '\033[1;33m'
            ciano = '\033[46m'
            magenta = '\033[45m'
            normal = '\033[0;0m'
    '''
    cyanClaro = "\033[1;36m"
    vermelho = '\033[31;1m'
    verde = '\033[32;1m'
    azul = '\033[34;1m'
    normal = '\033[0;0m'
    amarelo = '\033[1;33m'
    ciano = '\033[46m'
    magenta = '\033[45m'
    normal = '\033[0;0m'
